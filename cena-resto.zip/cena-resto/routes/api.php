<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AccountController;
use App\Http\Controllers\MenuController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
// accounts
Route::match(['get', 'post'], '/accounts/list',     [AccountController::class, 'list']);
Route::match(['get', 'post'], '/accounts/item',     [AccountController::class, 'item']);
Route::match(['get', 'post'], '/accounts/create',   [AccountController::class, 'create']);
Route::match(['get', 'post'], '/accounts/update',   [AccountController::class, 'update']);
Route::match(['get', 'post'], '/accounts/delete',   [AccountController::class, 'delete']);

//menu
Route::match(['get', 'post'], '/menus/list',     [MenuController::class, 'list']);
Route::match(['get', 'post'], '/menus/item',     [MenuController::class, 'item']);
Route::match(['get', 'post'], '/menus/create',   [MenuController::class, 'create']);
Route::match(['get', 'post'], '/menus/update',   [MenuController::class, 'update']);
Route::match(['get', 'post'], '/menus/delete',   [MenuController::class, 'delete']);

