<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Accounts;
use App\Models\Menus;

class PageController extends Controller
{
    public function dashboard(){
        return view('dashboard');
    }
    public function accounts(){
        $data = Accounts::all();
        return view('accounts', compact('data'));
    }
    public function menus(){
        $data = Menus::all();
        return view('menus', compact('data'));
    }

}
