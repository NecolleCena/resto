<?php $__env->startSection('title'); ?>
    Menus
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="main-modal" tabindex="-1" role="dialog" aria-labelledby="main-modalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="main-modalLabel">Menu Information</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <div class="modal-body">

                <input type="hidden" class="form-control" id="id">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="Name">Name</label>
                            <input type="text" class="form-control" id="Name">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="Description">Description</label>
                            <input type="Description" class="form-control" id="Description">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="Prize">Prize</label>
                            <input type="Prize" class="form-control" id="Prize">
                        </div>
                    </div>
                </div>
            </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button onclick="Save()"type="button" class="btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-primary">
                            <h4 class="card-title">Menus</h4>
                            <button onclick="Add()" type="button" class="btn btn-sm btn-success">Add New</button>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-hover">
                                <thead class="text-warning">
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Prize</th>
                                    <th>Actions</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($menu->id); ?></td>
                                        <td><?php echo e($menu->Name); ?></td>
                                        <td><?php echo e($menu->Description); ?></td>
                                        <th><?php echo e($menu->Prize); ?></td>
                                        <td>
                                            <button onclick="Edit(<?php echo e($menu->id); ?>)" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></button>
                                            <button onclick="delete(<?php echo e($menu->id); ?>)" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

    $('[id^="menu-"]').removeClass('active')
    $('#menu-menus').addClass('active')

    var modal = '#main-modal';

    function Add() {

        $('#id').val('-1')
        $('#Name').val('')
        $('#Description').val('')
        $('#Prize).val('')

        $(modal).modal({
            'show': true
        })
    }

    function Edit(id) {

        Controller.Post('/api/menus/item', { 'id': id }).done(function(result) {

            $('#id').val(result.id)
            $('#Name').val(result.Name)
            $('#Description').val(result.Description)
            $('#Prize').val(result.Priza)

            $(modal).modal({
                'show': true
            })

        })

    }

    function Save() {

        var data = {
            id              : $('#id').val(),
            Name            : $('#Name').val(),
            Description     : $('#Description').val(),
            Priza           : $('#Priza').val(),
        }

        if(data.id == -1) {
            Controller.Post('/api/menus/create', data).done(function(result) {
                window.location.reload()
            })
        }
        else if(data.id > 0) {
            Controller.Post('/api/menus/update', data).done(function(result) {
                window.location.reload()
            })
        }

    }

    function Delete(id) {
        bootbox.confirm({
            size: "small",
            message: "Delete this item?",
            callback: function(result){
                if(result) {
                    Controller.Post('/api/menus/delete', { 'id': id }).done(function(result) {
                        window.location.reload()
                    })
                }
            }
        })
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\cena-resto\resources\views/menus.blade.php ENDPATH**/ ?>